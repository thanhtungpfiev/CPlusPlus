#pragma once
#include <string>

struct Employee
{
 int id;
 float salary;
 std::string name;
};

