#pragma once

void toUpper(char *inputString);