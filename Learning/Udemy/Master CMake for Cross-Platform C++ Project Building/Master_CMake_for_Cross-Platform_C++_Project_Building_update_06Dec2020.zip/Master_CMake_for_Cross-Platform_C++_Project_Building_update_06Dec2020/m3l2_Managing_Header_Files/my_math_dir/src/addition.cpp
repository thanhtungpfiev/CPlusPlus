#include "addition.h"

float addition( float num1, float num2 ){
	return num1+num2;
}
