#include "division.h"

float division(float num1, float num2){
	return num1/num2;
}
