#pragma once

int sum(int a, int b);

