#pragma once
#include <vector>

int countPositives(std::vector<int> const& inputVector);
