#include <iostream>

int main(int argc, char **argv)
{
  std::cout << "Do something with your library code\n";
  return 0;
}
