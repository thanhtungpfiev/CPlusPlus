#pragma once

#include <vector>

std::vector<int> generateNumbers(int n, int limit);
